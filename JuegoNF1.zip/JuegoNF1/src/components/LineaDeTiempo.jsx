// src/components/LineaDeTiempo.jsx
// VERSIÓN FINAL CON CSS NORMAL (CLASES)

import React from 'react';

// Recibe la función 'onSiguiente' de App.jsx
function LineaDeTiempo({ onSiguiente }) {

  // Ruta a tu imagen general (verifica que exista en /public)
  const imagenGeneralLineaTiempo = '/AESNF-NF1.jpg'; // O el nombre que le hayas puesto

  // Datos de las etapas
  const etapas = [
    { id: 'infancia', titulo: 'Infancia (0-5 años)', desc: 'Aparición de manchas café con leche (>6), posible pseudoartrosis. Inicio seguimiento.' },
    { id: 'niñez', titulo: 'Niñez (6-12 años)', desc: 'Aparición de efélides axilares/inguinales, nódulos de Lisch en el iris (examen oftalmológico). Posible glioma óptico (vigilar), dificultades de aprendizaje.' },
    { id: 'adolescencia', titulo: 'Adolescencia (13-18 años)', desc: 'Aumento en número y tamaño de neurofibromas cutáneos. Posible escoliosis. Inicio de control de tensión arterial.' },
    { id: 'adultez', titulo: 'Adultez (>18 años)', desc: 'Neurofibromas pueden seguir creciendo. Riesgo (bajo) de tumores malignos de la vaina nerviosa (MPNST). Seguimiento continuo. Consejo genético.' }
  ];

  return (
    // Contenedor principal del componente (padding viene de App.jsx)
    <div>
      <h1>El Viaje con NF1: Manifestaciones por Edad</h1> {/* Estilo h1 general */}

      {/* Imagen General */}
      <div style={{ marginBottom: '2rem', textAlign: 'center' }}> {/* Estilo inline simple para centrar y margen */}
        <img
          src={imagenGeneralLineaTiempo}
          alt="Línea de tiempo conceptual NF1"
          className="linea-tiempo-imagen" // Clase definida en App.css para controlar tamaño/sombra
          onError={(e) => {
            e.target.onerror = null;
            e.target.src="https://via.placeholder.com/500x250?text=Imagen+no+cargada"; // Placeholder
          }}
         />
      </div>

      {/* Lista de Etapas */}
      {/* Aplicamos la clase CSS al contenedor */}
      <div className="etapas-container">
        <h2>Etapas Clave:</h2> {/* Estilo h2 general */}
        {etapas.map((etapa) => (
          // Aplicamos la clase CSS a cada tarjeta
          <div key={etapa.id} className="etapa-card">
             {/* Estos elementos usarán los estilos de .etapa-card h3/p */}
            <h3>{etapa.titulo}</h3>
            <p>{etapa.desc}</p>
          </div>
        ))}
      </div>

      {/* Botón para avanzar */}
      <div style={{ textAlign: 'center', marginTop: '2.5rem' }}> {/* Estilo inline para centrar y margen */}
        <button
          onClick={onSiguiente}
          // Usa estilos base de <button> de App.css
          // Puedes añadir una clase extra si quieres estilos específicos
          // className="linea-tiempo-button"
        >
          Siguiente: Identificar Criterios
        </button>
      </div>
    </div>
  );
}

export default LineaDeTiempo;