// src/components/PantallaInicio.jsx

import React from 'react';

// Recibe la función onComenzar de App.jsx
function PantallaInicio({ onComenzar }) {
  return (
    // Usamos una clase específica para estilizarla
    <div className="pantalla-inicio">
      <div className="inicio-contenido">
        <h1>Explorador Interactivo NF1</h1>
        <p className="subtitulo">Un viaje de aprendizaje sobre Neurofibromatosis Tipo 1</p>

        {/* Aquí puedes añadir logos si quieres */}
        {/* <img src="/logo-institucion.png" alt="Logo" className="logo-inicio"/> */}

        <button onClick={onComenzar} className="boton-inicio-grande">
          Comenzar
        </button>

        <div className="creditos-inicio">
          <p>Desarrollado por: [Sara Beltran, Joseph Vargas]</p>
          <p>Basado en información médica general. Consulte siempre a un profesional.</p>
          {/* Puedes añadir año, versión, etc. */}
        </div>
      </div>
    </div>
  );
}

export default PantallaInicio;