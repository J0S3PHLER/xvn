// src/components/PantallaFinal.jsx

import React from 'react';

// Recibe la función onReiniciar de App.jsx
function PantallaFinal({ onReiniciar }) {
  return (
    // Añadimos la clase CSS para aplicar estilos desde App.css
    <div className="pantalla-final-box">

      <h1>¡Felicidades!</h1> {/* Aplicará estilos h1 de App.css */}
      <p>
        Has completado el recorrido interactivo sobre la Neurofibromatosis Tipo 1.
        Esperamos que hayas aprendido sobre sus aspectos genéticos, diagnóstico y manejo.
      </p>
      {/* Añadimos la clase CSS para el disclaimer */}
      <p className="disclaimer">
        Recuerda: esta es una herramienta educativa. Consulta siempre a profesionales de la salud para obtener información médica precisa y personalizada.
      </p>

      <button
        onClick={onReiniciar}
        // Quitamos las clases de Tailwind, usará los estilos base de <button>
        // y los específicos de .pantalla-final-box button de App.css
      >
        Volver a Jugar {/* <-- TEXTO AHORA DENTRO DE LAS ETIQUETAS */}
      </button>

    </div>
  );
}

export default PantallaFinal;