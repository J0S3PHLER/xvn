// src/components/DecidirTratamiento.jsx
// VERSIÓN CORREGIDA v3 - TEXTO COMPLETO Y RULETA SINCRONIZADA

import React, { useState, useEffect } from 'react'; // Importamos useEffect por si acaso
import { Wheel } from 'react-custom-roulette';

// --- DATOS DE ESCENARIOS (VERSIÓN COMPLETA Y CORRECTA) ---
const escenarios = [
  {
    id: 'seguimiento_neurofibromas',
    titulo: 'Manejo de Neurofibromas Cutáneos Nuevos',
    descripcion: 'Han aparecido varios neurofibromas nuevos en tu piel. No causan dolor significativo, pero son visibles y te generan cierta preocupación estética y sobre su naturaleza.',
    opciones: [
      {
        id: 'op1',
        texto: 'Vigilancia activa (controles anuales y autoexamen)',
        efecto: 'Menor intervención, seguimiento de cambios.',
        probabilidades: { exito: 90, fracaso: 10 }, // Solo exito/fracaso
        resultados: {
          exito: 'Decides mantener la vigilancia estricta. En el control anual y tus autoexámenes, los neurofibromas se mantienen estables en tamaño y número. ¡Buena monitorización!',
          fracaso: 'Decides vigilar, pero notas que uno de ellos ha crecido rápidamente o ha cambiado de textura. Consultas y se recomienda una biopsia/extirpación para estudio.'
        }
      },
      {
        id: 'op2',
        texto: 'Considerar extirpación quirúrgica de los más visibles',
        efecto: 'Mejora estética posible, pero riesgo de cicatriz y recurrencia.',
        probabilidades: { exito: 75, efecto_secundario: 20, fracaso: 5 }, // Los tres tipos
        resultados: {
          exito: 'Hablas con el dermatólogo y decides extirpar los dos más prominentes. La cirugía va bien y el resultado estético es satisfactorio, con cicatrices mínimas.',
          efecto_secundario: 'La cirugía para extirparlos va bien, pero una de las cicatrices queda algo más visible de lo esperado o hay una pequeña infección que requiere tratamiento antibiótico tópico.',
          fracaso: 'Te sometes a la extirpación, pero al cabo de unos meses, notas que en la misma zona vuelve a crecer un neurofibroma.'
        }
      },
      {
        id: 'op3',
        texto: 'Probar tratamiento tópico experimental (si disponible)',
        efecto: 'Potencial reducción no invasiva, pero eficacia limitada y posible irritación.',
        probabilidades: { exito: 30, efecto_secundario: 40, fracaso: 30 }, // Los tres tipos
        resultados: {
          exito: 'Participas en un ensayo o usas una crema específica. Notas una ligera reducción en el tamaño de algunos neurofibromas después de varios meses de uso constante.',
          efecto_secundario: 'Pruebas un tratamiento tópico, pero te causa irritación significativa en la piel y tienes que suspenderlo.',
          fracaso: 'Usas el tratamiento tópico diligentemente durante meses, pero no observas ningún cambio apreciable en los neurofibromas.'
        }
      }
    ]
  },
  {
    id: 'manejo_dolor_plexiforme',
    titulo: 'Manejo del Dolor por Neurofibroma Plexiforme',
    descripcion: 'El neurofibroma plexiforme que tienes en la pierna ha empezado a causar dolor neuropático más frecuente (quemazón, pinchazos).',
    opciones: [
       {
         id: 'opA',
         texto: 'Tratamiento Farmacológico (Gabapentina/Pregabalina)',
         efecto: 'Alivio del dolor neuropático, pero posibles efectos secundarios (somnolencia, mareo).',
         probabilidades: { exito: 65, efecto_secundario: 25, fracaso: 10 }, // Los tres tipos
         resultados: {
           exito: 'Inicias tratamiento con gabapentina ajustando la dosis gradualmente. El dolor mejora significativamente, permitiéndote realizar tus actividades diarias con más comodidad.',
           efecto_secundario: 'Tomas pregabalina y aunque el dolor mejora algo, experimentas bastante somnolencia durante el día, lo que afecta tu concentración. Debes hablar con tu médico para ajustar dosis o cambiar.',
           fracaso: 'Pruebas con dosis adecuadas de gabapentina y luego pregabalina, pero lamentablemente, no consigues un alivio suficiente del dolor neuropático.'
         }
       },
       {
         id: 'opB',
         texto: 'Terapias Físicas y Ocupacionales',
         efecto: 'Mejora funcional, manejo no farmacológico, requiere constancia.',
         probabilidades: { exito: 50, fracaso: 50 }, // Solo exito/fracaso
         resultados: {
           exito: 'Trabajas con fisioterapia y terapia ocupacional. Aprendes técnicas de manejo del dolor, ejercicios de movilidad y adaptaciones que te ayudan a sobrellevar mejor el dolor y mantener tu independencia.',
           fracaso: 'Realizas las terapias indicadas, pero el dolor neuropático persiste sin grandes cambios y la funcionalidad sigue limitada por el mismo.'
         }
       },
       {
         id: 'opC',
         texto: 'Evaluar Cirugía de Resección (si es candidato)',
         efecto: 'Potencial alivio duradero, pero cirugía compleja con riesgos neurológicos/vasculares.',
         probabilidades: { exito: 40, efecto_secundario: 35, fracaso: 25 }, // Los tres tipos
         resultados: {
           exito: 'Tras una evaluación exhaustiva, se considera viable la cirugía. Se logra resecar una parte significativa del plexiforme que comprimía nervios, y el dolor postoperatorio mejora notablemente.',
           efecto_secundario: 'La cirugía es técnicamente difícil. Se reseca parte del tumor, pero quedas con una leve debilidad permanente en el pie o una zona de parestesia (hormigueo) residual.',
           fracaso: 'Te sometes a cirugía, pero debido a la infiltración del tumor en estructuras vitales, no se puede resecar lo suficiente para aliviar el dolor, o incluso este empeora tras la intervención.'
         }
       }
    ]
  }
];
// --- FIN DATOS ESCENARIOS ---

// --- Datos para la Ruleta (Base con estilos) ---
const baseRouletteSegments = {
    exito: { option: 'ÉXITO', style: { backgroundColor: '#22c55e', textColor: '#ffffff' } },
    efecto_secundario: { option: 'E.SECUNDARIO', style: { backgroundColor: '#f59e0b', textColor: '#ffffff' } },
    fracaso: { option: 'FRACASO', style: { backgroundColor: '#f43f5e', textColor: '#ffffff' } }
};
// ---------------------------------------------

function DecidirTratamiento({ onDecisionTomada }) {
  const [indiceEscenario, setIndiceEscenario] = useState(0);
  const [resultadoTexto, setResultadoTexto] = useState(null);
  const [ultimoResultadoTipo, setUltimoResultadoTipo] = useState(null);
  const [mustSpin, setMustSpin] = useState(false);
  const [prizeNumber, setPrizeNumber] = useState(0);
  const [currentRouletteData, setCurrentRouletteData] = useState([]);
  const [chosenOptionResultados, setChosenOptionResultados] = useState(null);

  const escenarioActual = escenarios[indiceEscenario];

  // --- Lógica REFINADA para elegir opción y preparar ruleta ---
  const handleElegirOpcion = (opcion) => {
    const { probabilidades, resultados } = opcion;
    const randomNum = Math.random() * 100;

    // 1. Determinar el resultado LÓGICO basado en probabilidades
    let tipoResultadoLogico = 'fracaso'; // Por defecto
    if (randomNum < probabilidades.exito) {
        tipoResultadoLogico = 'exito';
    } else if (probabilidades.efecto_secundario && randomNum < probabilidades.exito + probabilidades.efecto_secundario) {
        tipoResultadoLogico = 'efecto_secundario';
    } // Si no cae en los anteriores, se queda como 'fracaso'

    // 2. Construir los segmentos que SÍ aparecerán en la ruleta ESTA VEZ
    let dataParaRuletaActual = [];
    if (probabilidades.exito > 0) dataParaRuletaActual.push(baseRouletteSegments.exito);
    if (probabilidades.efecto_secundario > 0) dataParaRuletaActual.push(baseRouletteSegments.efecto_secundario);
    if (probabilidades.fracaso > 0) dataParaRuletaActual.push(baseRouletteSegments.fracaso);

    // 3. Encontrar el ÍNDICE del resultado lógico DENTRO de los segmentos que SÍ se mostrarán
    let indiceGanador = -1;
    if (tipoResultadoLogico === 'exito') {
        indiceGanador = dataParaRuletaActual.findIndex(s => s.option === 'ÉXITO');
    } else if (tipoResultadoLogico === 'efecto_secundario') {
        indiceGanador = dataParaRuletaActual.findIndex(s => s.option === 'E.SECUNDARIO');
    } else { // fracaso
        indiceGanador = dataParaRuletaActual.findIndex(s => s.option === 'FRACASO');
    }

    // --- Depuración ---
    console.log("--------------------------");
    console.log(" Opción:", opcion.texto.substring(0,20)+"...");
    console.log(" Random:", randomNum.toFixed(1));
    console.log(" Probs:", probabilidades);
    console.log(" Resultado Lógico:", tipoResultadoLogico);
    console.log(" Segmentos Ruleta:", dataParaRuletaActual.map(s => s.option));
    console.log(" Índice Ganador Ruleta:", indiceGanador);
    console.log("--------------------------");
    // --- Fin Depuración ---

    // Validar que todo esté correcto antes de girar
    if (indiceGanador === -1 || dataParaRuletaActual.length === 0) {
        console.error("¡ERROR CRÍTICO! No se pudo determinar el índice ganador o los datos de la ruleta están vacíos.");
        // Mostrar resultado directamente sin ruleta como fallback
        setUltimoResultadoTipo(tipoResultadoLogico);
        setResultadoTexto(resultados[tipoResultadoLogico] || "Error al obtener el texto del resultado.");
        setMustSpin(false); // Asegurar que no intente girar
        return;
    }

    // 4. Preparar estado para la ruleta y el resultado final
    setPrizeNumber(indiceGanador);             // Qué segmento debe ganar
    setCurrentRouletteData(dataParaRuletaActual); // Qué segmentos mostrar
    setChosenOptionResultados(resultados);     // Textos de resultado para después
    setUltimoResultadoTipo(tipoResultadoLogico); // Guardar el tipo REAL que salió
    setResultadoTexto(null);                   // Ocultar resultado anterior
    setMustSpin(true);                         // ¡A girar!
  };

  // --- Se ejecuta cuando la ruleta PARA de girar ---
  const handleStopSpinning = () => {
    console.log(`Ruleta parada. Debe mostrar resultado para: ${ultimoResultadoTipo}`);
    setMustSpin(false); // Ya no necesitamos que gire

    // Mostrar el texto correspondiente al TIPO DE RESULTADO LÓGICO que determinamos antes
    if (chosenOptionResultados && chosenOptionResultados[ultimoResultadoTipo]) {
      setResultadoTexto(chosenOptionResultados[ultimoResultadoTipo]);
    } else {
      console.error(`Error: No se encontró texto para el resultado '${ultimoResultadoTipo}'`);
      setResultadoTexto("Ocurrió un error al mostrar el resultado.");
    }
  };

  // --- Avanzar al siguiente escenario o final ---
  const avanzarDesdeResultado = () => {
    // Resetear estados para la siguiente ronda
    setResultadoTexto(null);
    setUltimoResultadoTipo(null);
    setCurrentRouletteData([]);
    setChosenOptionResultados(null);
    setMustSpin(false);
    // Avanzar
    if (indiceEscenario < escenarios.length - 1) {
      setIndiceEscenario(indiceEscenario + 1);
    } else {
      onDecisionTomada(); // Ir a pantalla final
    }
  };

  // --- RETURN del Componente ---
  return (
    <div>
      <h1>Decisiones y Manejo</h1>

      {/* Mostrar Escenario: si NO está girando Y NO hay resultado final */}
      {!mustSpin && !resultadoTexto && escenarioActual && (
        <div className="escenario-box">
          <h2>{escenarioActual.titulo}</h2>
          <p>{escenarioActual.descripcion}</p> {/* Texto completo aquí */}
          <div className="opciones-grid">
            {escenarioActual.opciones.map(opcion => (
              <div key={opcion.id} className="opcion-card">
                <div>
                  <p><strong>{opcion.texto}</strong></p> {/* Texto completo aquí */}
                  <p style={{fontSize: '0.85em', fontStyle: 'italic', color: '#555'}}>{opcion.efecto}</p> {/* Texto completo aquí */}
                </div>
                <button onClick={() => handleElegirOpcion(opcion)}>
                  Seleccionar y Girar Ruleta
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Mostrar Ruleta: si mustSpin es true */}
      {mustSpin && (
        <div className="ruleta-container">
          <h3>Girando la Ruleta del Destino...</h3>
          {currentRouletteData.length > 0 ? (
            <Wheel
              mustStartSpinning={mustSpin}
              prizeNumber={prizeNumber} // Índice que DEBE ganar
              data={currentRouletteData} // Segmentos REALES a mostrar
              onStopSpinning={handleStopSpinning}
              backgroundColors={['#f8fafc', '#f1f5f9']} // Estilos visuales
              textColors={['#1e293b']}
              outerBorderColor={"#e2e8f0"}
              outerBorderWidth={5}
              innerBorderColor={"#e2e8f0"}
              innerBorderWidth={15}
              radiusLineColor={"#e2e8f0"}
              radiusLineWidth={2}
              fontSize={14}
              spinDuration={0.8} // Más rápido para probar
            />
          ) : (
            <p style={{color: 'red'}}>Error: No se pudieron cargar los datos de la ruleta.</p>
          )}
        </div>
      )}

      {/* Mostrar Resultado Final: si NO está girando Y SÍ hay resultadoTexto */}
      {!mustSpin && resultadoTexto && (
        // Usar el TIPO LÓGICO para la clase y el título
        <div className={`resultado-box resultado-${ultimoResultadoTipo}`}>
          <h3>Resultado ({ultimoResultadoTipo?.replace('_', ' ') || 'Definitivo'}):</h3>
          <p>{resultadoTexto}</p> {/* Texto correspondiente al tipo lógico */}
          <button onClick={avanzarDesdeResultado}>
            {indiceEscenario < escenarios.length - 1 ? 'Continuar...' : 'Ver Resumen Final'}
          </button>
        </div>
      )}
    </div>
  );
}

export default DecidirTratamiento;