// src/components/Bienvenida.jsx
// VERSIÓN CORREGIDA (SIN DOBLE DECLARACIÓN)

import React from 'react';
// Asegúrate que el nombre del archivo importado sea el correcto ('Personaje' o 'PersonajesInfo')
import PersonajesInfo from './Personaje';

// --- CONSTANTES DEFINIDAS FUERA DEL COMPONENTE (¡Correcto!) ---
const infoGenetica = {
  nombre: "Neurofibromatosis Tipo 1 (NF1)",
  mutacion: "Causada por una mutación patogénica en el gen *NF1*.",
  tipoMutacion: "Variantes incluyen mutaciones puntuales (sustituciones, inserciones/deleciones pequeñas que causan cambio de marco o codón de parada prematuro - *mutaciones truncantes* son comunes), deleciones grandes, etc.",
  genFuncion: "Codifica la neurofibromina, una proteína supresora de tumores que regula negativamente la vía de señalización RAS/MAPK, controlando así el crecimiento y la división celular.",
  cromosoma: "Localizado en el brazo largo (q) del cromosoma 17, banda 1, sub-banda 1.2 (notación: **17q11.2**).",
  herencia: "**Autosómica Dominante**.",
  penetranciaExpresividad: "**Penetrancia completa relacionada con la edad** (casi todos los individuos con la mutación desarrollan *algún* signo con el tiempo) pero **expresividad muy variable** (la severidad y tipo de síntomas varían enormemente entre personas, incluso en la misma familia).",
  deNovo: "Aproximadamente el **50% de los casos** surgen por mutaciones *de novo* (nuevas en el individuo, no heredadas). Esto puede deberse a mutaciones en gametos parentales o mosaicismo.",
  genotipoAA: "El genotipo **AA** (homocigoto dominante) se considera generalmente **letal embrionario** o asociado a un fenotipo extremadamente severo en humanos, por lo que no se observa en la práctica clínica habitual."
};

const infoCruces = [
  {
    parentales: "aa (Sano) × aa (Sano)",
    descendencia: [ { genotipo: "aa", fenotipo: "Sano", prob: "100%" } ],
    explicacion: "Si ninguno de los padres tiene la mutación NF1, todos sus hijos serán sanos respecto a esta condición."
  },
  {
    parentales: "Aa (Afectado) × aa (Sano)",
    descendencia: [
      { genotipo: "Aa", fenotipo: "Afectado (NF1)", prob: "50%" },
      { genotipo: "aa", fenotipo: "Sano", prob: "50%" }
    ],
    explicacion: "Este es el escenario más común al planificar familia. Cada hijo tiene un 50% de probabilidad de heredar la mutación y desarrollar NF1, y un 50% de ser sano."
  },
  {
    parentales: "Aa (Afectado) × Aa (Afectado)",
    descendencia: [
      { genotipo: "AA", fenotipo: "Muy Severo/Letal", prob: "25%" },
      { genotipo: "Aa", fenotipo: "Afectado (NF1)", prob: "50%" },
      { genotipo: "aa", fenotipo: "Sano", prob: "25%" }
    ],
    explicacion: "Cuando ambos padres tienen NF1, existe un 25% de riesgo de una forma muy grave (AA), un 50% de tener NF1 (Aa) y un 25% de ser sano (aa)."
  }
];
// --- FIN CONSTANTES ---


function Bienvenida({ onComenzar }) {
  // --- ¡YA NO REDECLARAMOS LAS CONSTANTES AQUÍ DENTRO! ---
  // Las constantes infoGenetica e infoCruces definidas arriba son accesibles directamente.

  return (
    // Contenedor principal
    <div style={{ padding: '1rem 2rem' }}>

      <h1 style={{ textAlign: 'center', marginBottom: '2rem' }}>¡Bienvenido/a al Explorador de NF1!</h1>

      {/* Caja de Información Genética Mejorada */}
      <div className="info-genetica-detallada">
        <h2>Información Clave sobre {infoGenetica.nombre}</h2>
        <div className="info-grid"> {/* Grid para organizar mejor */}
          <div><strong>Causa:</strong> {infoGenetica.mutacion}</div>
          <div><strong>Tipos Comunes:</strong> {infoGenetica.tipoMutacion}</div>
          <div><strong>Función del Gen NF1:</strong> {infoGenetica.genFuncion}</div>
          <div><strong>Localización:</strong> {infoGenetica.cromosoma}</div>
          <div><strong>Herencia:</strong> {infoGenetica.herencia}</div>
          <div><strong>Importante:</strong> {infoGenetica.penetranciaExpresividad}</div>
          <div><strong>Mutaciones Nuevas (*de novo*):</strong> {infoGenetica.deNovo}</div>
          <div><strong>Sobre el Genotipo AA:</strong> <em style={{fontSize: '0.9em'}}>{infoGenetica.genotipoAA}</em></div>
        </div>
      </div>

      {/* Sección de Probabilidades de Herencia (ESTA PARTE YA ESTABA BIEN) */}
      <div className="info-cruces">
        <h2>Probabilidades de Herencia (Ejemplos)</h2>
        {infoCruces.map((cruz, index) => (
          <div key={index} className="cruce-card">
            <h3>Cruce: {cruz.parentales}</h3>
            <div className="descendencia-tabla">
              {cruz.descendencia.map((desc, i) => (
                <div key={i} className="descendencia-item">
                  <span className="genotipo-tag-cruce">{desc.genotipo}</span>
                  <span className="fenotipo-cruce">{desc.fenotipo}</span>
                  <span className="prob-cruce">{desc.prob}</span>
                </div>
              ))}
            </div>
            <p className="explicacion-cruce">{cruz.explicacion}</p>
          </div>
        ))}
         <p style={{fontSize: '0.8em', textAlign: 'center', marginTop: '1rem', color: '#666'}}>
           (Nota: Estos son patrones clásicos. El consejo genético real es complejo y personalizado.)
         </p>
      </div>

      {/* Personajes */}
      <PersonajesInfo />

      {/* Botón para comenzar */}
      <div style={{ textAlign: 'center', marginTop: '2.5rem', marginBottom: '1.5rem' }}>
        <button
          onClick={onComenzar}
          className="boton-comenzar-grande" // Clase nueva para posible estilo diferente
        >
          Comenzar el Viaje
        </button>
      </div>
    </div>
  );
}

export default Bienvenida;