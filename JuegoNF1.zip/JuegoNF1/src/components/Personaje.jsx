// src/components/PersonajesInfo.jsx (o Personaje.jsx)
// VERSIÓN FINAL CON CSS NORMAL (CLASES) Y ERROR CORREGIDO

import React from 'react';

// Datos de los personajes
const personajesData = [
  {
    id: 'david',
    nombre: 'David',
    edad: 30,
    genotipo: 'aa',
    tipo: 'Homocigoto Recesivo (No afectado)',
    historia: 'Arquitecto. No tiene NF1 ni antecedentes familiares conocidos. Representa a la población general sin la mutación relevante.',
    imagen: '/personaje_david.png' // <-- Necesitas esta imagen en /public
  },
  {
    id: 'ava',
    nombre: 'Ava',
    edad: 25,
    genotipo: 'Aa',
    tipo: 'Heterocigoto (Afectado con NF1)',
    historia: 'Profesora. Diagnosticada en la infancia (mutación de novo). Tiene manchas café con leche, efélides y algunos neurofibromas cutáneos. Requiere seguimiento anual.',
    imagen: '/personaje_ava.png' // <-- Necesitas esta imagen en /public
  },
  {
    id: 'samuel',
    nombre: 'Samuel',
    edad: 40,
    genotipo: 'Aa',
    tipo: 'Heterocigoto (Afectado, Expresión Variable)',
    historia: 'Escritor. Heredó NF1. Tuvo glioma óptico, tiene neurofibromas plexiformes con dolor ocasional y escoliosis leve. Requiere manejo multidisciplinar.',
    imagen: '/personaje_samuel.png' // <-- Necesitas esta imagen en /public
  },
   {
    id: 'chloe',
    nombre: 'Chloe',
    edad: 28,
    genotipo: 'aa',
    tipo: 'Familiar No Afectado',
    historia: 'Hermana de Samuel. Sabe que no heredó la mutación. La condición de su hermano influye en sus pensamientos sobre el consejo genético y planificación familiar.',
    imagen: '/personaje_chloe.png' // <-- Necesitas esta imagen en /public
  }
];

// Componente pequeño para mostrar una tarjeta de personaje individual
// Aplicamos la clase CSS a la tarjeta
function TarjetaPersonaje({ personaje }) {
  return (
    <div className="personaje-card">
      <img
         src={personaje.imagen}
         alt={`Avatar de ${personaje.nombre}`}
         // Usa estilos base de img y los de .personaje-card img
         onError={(e) => { e.target.onerror = null; e.target.src="https://via.placeholder.com/80?text=?" }}
      />
      {/* El div para el texto ya está dentro de personaje-card, usará sus estilos */}
      <div>
        {/* Estos elementos usarán los estilos de .personaje-card h4/p */}
        <h4>{personaje.nombre}, {personaje.edad} años</h4>
        <p>Genotipo: <span className="genotipo-tag">{personaje.genotipo}</span> ({personaje.tipo})</p> {/* Clase para el tag */}
        <p>{personaje.historia}</p>
      </div>
    </div>
  );
}

// Componente principal que muestra todas las tarjetas
// (Asegúrate que el nombre de la función coincida con cómo la importas en Bienvenida.jsx)
function PersonajesInfo() {
  return (
    // Aplicamos la clase CSS al contenedor principal
    <div className="personajes-container">
      {/* Título opcional con estilos generales */}
      <h2>Conoce a los Personajes</h2>
      {/* Aplicamos la clase CSS a la grilla */}
      <div className="personajes-grid">
        {personajesData.map(p => ( // Abrimos paréntesis
          // Renderiza una tarjeta por cada personaje 'p'
          <TarjetaPersonaje key={p.id} personaje={p} />
        ))} {/* <--- PARÉNTESIS DE CIERRE CORRECTO --- */}
      </div>
    </div>
  );
}

// Asegúrate de exportar con el nombre correcto
export default PersonajesInfo; // O export default Personaje; si así se llama el archivo/función