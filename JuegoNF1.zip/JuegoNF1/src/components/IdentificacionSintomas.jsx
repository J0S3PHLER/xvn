// src/components/IdentificacionSintomas.jsx
// VERSIÓN CON CLIC EN DIAGRAMA + MINI-JUEGO DRAG-AND-DROP

import React, { useState, useRef, useCallback } from 'react';
import Modal from 'react-modal';
import { useDrag, useDrop } from 'react-dnd'; // Importar hooks de react-dnd

import patientDiagram from '/AESNF-NF1.jpg'; // O tu imagen

// Datos de criterios (mantener todos)
const criteriosNF1 = [ /* ... Tu lista completa de criterios ... */
    { key: 'cafe_au_lait', name: 'Manchas Café con Leche / Cafe-au-lait macules', description: 'Seis o más manchas de >5mm en prepúberes o >15mm postpúberes.', points: 1 },
    { key: 'lisch_nodule', name: 'Nódulos de Lisch', description: 'Dos o más hamartomas pigmentados en el iris (requiere examen oftalmológico).', points: 1 },
    { key: 'neurofibroma', name: 'Neurofibromas Cutáneos / Cutaneous neurofibromas', description: 'Dos o más neurofibromas de cualquier tipo.', points: 1 },
    { key: 'plexiform_neurofibroma', name: 'Neurofibroma Plexiforme / Plexiform neurofibromas', description: 'Uno o más neurofibromas plexiformes.', points: 1 },
    { key: 'optic_glioma', name: 'Glioma Óptico / Optic glioma', description: 'Tumor en el nervio óptico (requiere pruebas de imagen).', points: 1 },
    { key: 'bone_lesion', name: 'Lesión Ósea / Osseous lesions', description: 'Displasia del esfenoides o pseudoartrosis tibial (requiere radiografías).', points: 1 },
    { key: 'family_history', name: 'Familiar de 1er Grado con NF1', description: 'Padre, madre, hermano/a o hijo/a con diagnóstico de NF1.', points: 1 },
    { key: 'cognitive_disorders', name: 'Alteraciones Cognitivas / Cognitive disorders', description: 'Dificultades de aprendizaje, TDAH y otros son más comunes en NF1.', points: 0 },
    { key: 'cardiovascular_malformation', name: 'Malformación Cardiovascular', description: 'Puede haber problemas como estenosis de la arteria renal o pulmonar.', points: 0 },
    { key: 'leukemia', name: 'Leucemia', description: 'Existe un riesgo ligeramente aumentado de ciertos tipos de leucemia infantil.', points: 0 },
    { key: 'mpnst', name: 'Tumor Maligno Vaina Nerviosa (MPNST)', description: 'Complicación rara pero grave, más frecuente en adultos con neurofibromas plexiformes.', points: 0 },
    { key: 'breast_cancer', name: 'Cáncer de Mama', description: 'Riesgo aumentado de cáncer de mama, especialmente en mujeres menores de 50 años.', points: 0 },
];

// Zonas clicables (para el clic directo en diagrama - ¡RECUERDA AJUSTARLAS!)
const zonasClicables = [ /* ... Tu lista de zonas con coordenadas x1,y1,x2,y2 ... */
    { key: 'cafe_au_lait', x1: 450, y1: 500, x2: 680, y2: 580 },
    { key: 'lisch_nodule', x1: 460, y1: 70,  x2: 680, y2: 150 },
    { key: 'neurofibroma', x1: 150, y1: 440, x2: 400, y2: 500 },
    { key: 'plexiform_neurofibroma', x1: 150, y1: 510, x2: 400, y2: 570 },
    { key: 'optic_glioma', x1: 150, y1: 110, x2: 400, y2: 190 },
    { key: 'bone_lesion',  x1: 450, y1: 600, x2: 680, y2: 680 },
    { key: 'cognitive_disorders', x1: 460, y1: 10,  x2: 680, y2: 65  },
    { key: 'cardiovascular_malformation', x1: 450, y1: 430, x2: 680, y2: 490 },
    { key: 'leukemia',       x1: 460, y1: 200, x2: 680, y2: 260 },
    { key: 'mpnst',          x1: 150, y1: 600, x2: 400, y2: 680 },
    { key: 'breast_cancer',  x1: 150, y1: 300, x2: 400, y2: 360 },
];

// --- Configuración para Drag and Drop ---
const ItemTypes = { SYMPTOM: 'symptom' };

// Datos para el mini-juego de arrastrar
const dragItemsData = [
    { id: 'drag-1', key: 'lisch_nodule', description: 'Pequeños hamartomas pigmentados en el iris', correctZone: 'cabeza' },
    { id: 'drag-2', key: 'neurofibroma', description: 'Bultos blandos sobre o bajo la piel, de tamaño variable', correctZone: 'tronco' },
    { id: 'drag-3', key: 'bone_lesion', description: 'Curvatura o adelgazamiento de huesos largos como la tibia', correctZone: 'extremidades' },
    // Añadir más si quieres complicarlo
];
// ---------------------------------------

Modal.setAppElement('#root');

// --- Componente Draggable ---
const DraggableSymptom = ({ item }) => {
    const [{ isDragging }, drag] = useDrag(() => ({
        type: ItemTypes.SYMPTOM,
        item: item, // Pasamos todo el objeto item
        collect: (monitor) => ({
            isDragging: !!monitor.isDragging(),
        }),
    }));

    return (
        <div
            ref={drag}
            className="draggable-item"
            style={{ opacity: isDragging ? 0.5 : 1 }}
        >
            {item.description}
        </div>
    );
};

// --- Componente DropZone ---
const DropZone = ({ zoneId, onDropItem, children }) => {
    const [{ isOver, canDrop }, drop] = useDrop(() => ({
        accept: ItemTypes.SYMPTOM,
        drop: (item) => onDropItem(item, zoneId), // Llama a la función del padre al soltar
        collect: (monitor) => ({
            isOver: !!monitor.isOver(),
            canDrop: !!monitor.canDrop(),
        }),
    }));

    let backgroundColor = 'rgba(255, 255, 255, 0.1)'; // Fondo base transparente
    if (canDrop && isOver) {
        backgroundColor = 'rgba(144, 238, 144, 0.5)'; // Verde claro si se puede soltar y está encima
    } else if (canDrop) {
        backgroundColor = 'rgba(255, 255, 0, 0.3)'; // Amarillo si se puede soltar
    }

    return (
        <div ref={drop} className={`drop-zone drop-zone-${zoneId}`} style={{ backgroundColor }}>
            {children} {/* Para poner un texto o icono dentro si queremos */}
        </div>
    );
};


// --- Componente Principal ---
function IdentificacionSintomas({ onDiagnosticoCompleto }) {

    // Estados principales (clic en diagrama)
    const [foundSymptoms, setFoundSymptoms] = useState([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedSymptomInfo, setSelectedSymptomInfo] = useState(null);
    const [clickCoords, setClickCoords] = useState(null);
    const imageRef = useRef(null);

    // Estados para el Drag and Drop
    const [availableDragItems, setAvailableDragItems] = useState(dragItemsData);
    const [matchedDragItems, setMatchedDragItems] = useState([]); // Guarda los {id, key} de los items emparejados

    // Calculamos criterios diagnósticos CUMPLIDOS (combinando ambas mecánicas)
    const criteriosNecesarios = 2;
    const criteriosCumplidos = foundSymptoms.reduce((count, key) => {
        const crit = criteriosNF1.find(c => c.key === key);
        return count + (crit?.points || 0);
    }, 0);

    // --- Funciones Clic Diagrama (sin cambios) ---
    const handleShowInfo = useCallback((symptomKey) => {
        const symptomInfo = criteriosNF1.find(item => item.key === symptomKey);
        if (symptomInfo) {
            setSelectedSymptomInfo(symptomInfo);
            setIsModalOpen(true);
        }
    }, []); // Usamos useCallback para optimizar

    const handleImageClick = useCallback((event) => {
        if (!imageRef.current) return;
        const rect = imageRef.current.getBoundingClientRect();
        const clickX_ventana = event.clientX;
        const clickY_ventana = event.clientY;
        const clickX_relativo = clickX_ventana - rect.left;
        const clickY_relativo = clickY_ventana - rect.top;
        const ratioX = imageRef.current.naturalWidth / rect.width;
        const ratioY = imageRef.current.naturalHeight / rect.height;
        const clickX_original = clickX_relativo * ratioX;
        const clickY_original = clickY_relativo * ratioY;

        setClickCoords({ x: clickX_original, y: clickY_original });
        console.log(`Click Original: (${clickX_original.toFixed(0)}, ${clickY_original.toFixed(0)})`);

        let zonaEncontrada = null;
        for (const zona of zonasClicables) {
            if (clickX_original >= zona.x1 && clickX_original <= zona.x2 && clickY_original >= zona.y1 && clickY_original <= zona.y2) {
                zonaEncontrada = zona; break;
            }
        }

        if (zonaEncontrada) {
            console.log("Zona clic encontrada:", zonaEncontrada.key);
            handleShowInfo(zonaEncontrada.key);
            // Añadir a foundSymptoms SI NO ESTÁ YA
            if (!foundSymptoms.includes(zonaEncontrada.key)) {
                setFoundSymptoms(prev => [...prev, zonaEncontrada.key]);
            }
        } else {
            console.log("Clic fuera de zonas definidas.");
        }
    }, [foundSymptoms, handleShowInfo]); // Dependencias de useCallback

    const closeModal = () => {
        setIsModalOpen(false);
        setSelectedSymptomInfo(null);
    };

    const checkDiagnosis = () => { /* ... igual que antes ... */
        if (criteriosCumplidos >= criteriosNecesarios) {
            alert(`¡Diagnóstico Confirmado! Has identificado ${criteriosCumplidos} criterios diagnósticos válidos.`);
            onDiagnosticoCompleto();
        } else {
            alert(`Aún no has identificado suficientes criterios diagnósticos. Necesitas ${criteriosNecesarios - criteriosCumplidos} más.`);
        }
    };

    // --- Función para manejar el Drop ---
    const handleDropSymptom = useCallback((droppedItem, targetZoneId) => {
        console.log(`Item ${droppedItem.key} (${droppedItem.description}) soltado en ${targetZoneId}`);
        if (droppedItem.correctZone === targetZoneId) {
            console.log("¡Correcto!");
            // Mover item de available a matched
            setAvailableDragItems(prev => prev.filter(item => item.id !== droppedItem.id));
            setMatchedDragItems(prev => [...prev, { id: droppedItem.id, key: droppedItem.key }]); // Guardamos id y key
            // Añadir a foundSymptoms SI NO ESTÁ YA
            if (!foundSymptoms.includes(droppedItem.key)) {
                setFoundSymptoms(prev => [...prev, droppedItem.key]);
            }
            // Aquí podríamos dar un feedback visual de éxito más claro
        } else {
            console.log("Incorrecto.");
            // Feedback de error (ej: un shake, un mensaje temporal)
        }
    }, [foundSymptoms]); // Dependencia

    // --- RETURN PRINCIPAL ---
    return (
        <div className="identificacion-layout">

            {/* Columna Izquierda: Imagen Clicable CON Drop Zones */}
            <div className="identificacion-imagen-col" style={{ position: 'relative' }}> {/* Necesario para posicionar dropzones */}
                <h2>Diagrama Guía (¡Haz Clic o Arrastra!)</h2>
                <div style={{ position: 'relative', cursor: 'crosshair' }}>
                    <img
                        ref={imageRef}
                        onClick={handleImageClick}
                        src={patientDiagram}
                        alt="Diagrama de manifestaciones NF1"
                        onError={(e) => { /* ... */ }}
                        style={{ display: 'block', maxWidth: '100%', height: 'auto' }} // Asegura que las dropzones se alineen bien
                    />
                    {/* Punto rojo de depuración (opcional) */}
                    {/* ... código del punto rojo ... */}

                    {/* --- Drop Zones (Posicionadas sobre la imagen) --- */}
                    {/* ¡NECESITARÁS AJUSTAR left, top, width, height con CSS o inline style! */}
                    <DropZone zoneId="cabeza" onDropItem={handleDropSymptom}>
                         <span className="drop-zone-label">Cabeza/Ojos</span>
                    </DropZone>
                    <DropZone zoneId="tronco" onDropItem={handleDropSymptom}>
                         <span className="drop-zone-label">Tronco/Piel</span>
                    </DropZone>
                    <DropZone zoneId="extremidades" onDropItem={handleDropSymptom}>
                         <span className="drop-zone-label">Extremidades/Huesos</span>
                    </DropZone>
                    {/* ------------------------------------------------- */}

                </div>
                <p style={{fontSize: '0.8rem', textAlign: 'center', marginTop: '0.5rem', color: '#555'}}>
                    Haz clic en zonas o arrastra las descripciones de la derecha a su área.
                </p>
            </div>

            {/* Columna Derecha: Mini-juego Drag & Drop + Lista Hallazgos */}
            <div className="identificacion-checklist-col">
                <h1>Identifica los Criterios</h1>

                {/* --- Mini-Juego Drag and Drop --- */}
                <div className="drag-drop-minigame">
                    <h3>Mini-Juego: Relaciona Síntoma y Zona</h3>
                    <p style={{fontSize: '0.9em', marginBottom: '1rem'}}>Arrastra cada descripción a la zona corporal correcta en el diagrama de la izquierda:</p>
                    <div className="drag-items-list">
                        {availableDragItems.map(item => (
                            <DraggableSymptom key={item.id} item={item} />
                        ))}
                        {availableDragItems.length === 0 && <p style={{ fontStyle: 'italic', color: 'green' }}>¡Bien hecho!</p>}
                    </div>
                </div>
                {/* ----------------------------- */}

                {/* Lista de Hallazgos (Combinados) */}
                <div className="my-4 w-full">
                    <h3 style={{fontSize: '1.1rem', fontWeight: 'bold', marginBottom: '0.5rem'}}>Hallazgos Identificados ({criteriosCumplidos} / {criteriosNecesarios} Criterios Diag.):</h3>
                    <ul className="hallazgos-lista">
                        {foundSymptoms.length > 0 ? (
                            // Creamos un set para evitar duplicados visuales si se añade por clic y drag
                            [...new Set(foundSymptoms)].map(key => {
                                const symptom = criteriosNF1.find(item => item.key === key);
                                const isMatchedByDrag = matchedDragItems.some(match => match.key === key); // Comprueba si se acertó arrastrando
                                return (
                                    <li key={key} style={{fontSize: '0.9rem', marginBottom: '0.25rem'}}>
                                        {symptom ? symptom.name : key}
                                        {symptom?.points > 0 && <span title="Criterio Diagnóstico NIH" style={{color: 'green', fontWeight: 'bold', marginLeft: '5px'}}>✓</span>}
                                        {isMatchedByDrag && <span title="Acertado en Mini-juego" style={{color: 'blue', marginLeft: '5px'}}>🎯</span>} {/* Icono si se acertó arrastrando */}
                                    </li>
                                );
                            })
                        ) : (
                            <li style={{fontStyle: 'italic', color: '#777', fontSize: '0.9rem'}}>
                                Haz clic en el diagrama o completa el mini-juego...
                            </li>
                        )}
                    </ul>
                </div>

                {/* Barra de progreso y botón (sin cambios) */}
                <div className="diagnostico-footer">
                    {/* ... barra ... */}
                    <div className="progreso-diagnostico">
                        <div className="progreso-barra" style={{ width: `${Math.min(100, (criteriosCumplidos / criteriosNecesarios) * 100)}%` }}></div>
                    </div>
                    <span className="progreso-texto">{criteriosCumplidos} / {criteriosNecesarios} Criterios Diagnósticos Identificados</span>
                    <button onClick={checkDiagnosis} disabled={criteriosCumplidos < criteriosNecesarios} className="comprobar-diagnostico-button">
                        Comprobar Diagnóstico
                    </button>
                </div>
            </div>

            {/* Modal (sin cambios) */}
            <Modal isOpen={isModalOpen} onRequestClose={closeModal} /* ... */ >
               {/* ... contenido ... */}
            </Modal>

        </div>
    );
}

export default IdentificacionSintomas;