// src/App.jsx
import React, { useState } from 'react';
import './App.css';
// Importa los componentes
import PantallaInicio from './components/PantallaInicio'; // ¡NUEVO!
import Bienvenida from './components/Bienvenida';
import LineaDeTiempo from './components/LineaDeTiempo';
import IdentificacionSintomas from './components/IdentificacionSintomas';
import DecidirTratamiento from './components/DecidirTratamiento';
import PantallaFinal from './components/PantallaFinal';

// Importa DndProvider y el backend
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

function App() {
  // Añadimos 'inicio' como el estado inicial
  const [currentScreen, setCurrentScreen] = useState('inicio');
  // Podríamos añadir un estado para el progreso general si quisiéramos

  const handleComenzarDesdeInicio = () => setCurrentScreen('bienvenida');
  const handleComenzarViaje = () => setCurrentScreen('lineaDeTiempo');
  const handleVerSintomas = () => setCurrentScreen('identificacion');
  const handleDiagnosticoCompleto = () => setCurrentScreen('tratamiento');
  const handleDecisionTomada = () => setCurrentScreen('final');
  const handleReiniciar = () => setCurrentScreen('inicio'); // Reinicia a la pantalla de inicio

  const renderScreen = () => {
    switch (currentScreen) {
      case 'inicio': // Nuevo caso
        return <PantallaInicio onComenzar={handleComenzarDesdeInicio} />;
      case 'bienvenida':
        return <Bienvenida onComenzar={handleComenzarViaje} />;
      case 'lineaDeTiempo':
        return <LineaDeTiempo onSiguiente={handleVerSintomas} />;
      case 'identificacion':
        return <IdentificacionSintomas onDiagnosticoCompleto={handleDiagnosticoCompleto} />;
      case 'tratamiento':
        return <DecidirTratamiento onDecisionTomada={handleDecisionTomada} />;
      case 'final':
        return <PantallaFinal onReiniciar={handleReiniciar} />;
      default:
        return <PantallaInicio onComenzar={handleComenzarDesdeInicio} />; // Fallback a inicio
    }
  };

  return (
    // Envolvemos TODO con DndProvider
    <DndProvider backend={HTML5Backend}>
      <div className="App">
        {/* Quitamos la clase app-content de aquí si los componentes ya la manejan */}
        <main className="app-content">
          {renderScreen()}
        </main>
        {/* Podríamos añadir un footer si queremos */}
        {/* <footer> <p>Explorador NF1 - Un Juego Interactivo</p> </footer> */}
      </div>
    </DndProvider>
  );
}

export default App;